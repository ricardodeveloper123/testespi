/**
 * 
 */

//call function exibir

exibir();

function exibir(){
	
	//persistent file search on localStorage
	var objSalvo = JSON.parse(localStorage.getItem('teste'));
	
	//search for elements with specific class
	//Populates with localStorage values
	$('#recebe').html('');	
	for(var i=0; i<objSalvo.length; i++){
		$('#recebe').append('<textarea class="texts" id='+i+'></textarea>');
		if(objSalvo[i]!=null){
			document.getElementById(i).style.width = objSalvo[i].width;
			document.getElementById(i).style.height = objSalvo[i].height;
			document.getElementById(i).style.backgroundColor=objSalvo[i].corCx;
			document.getElementById(i).style.color=objSalvo[i].corTxt;
			document.getElementById(i).style.fontSize=objSalvo[i].fontSize+'pt';
			document.getElementById(i).value=objSalvo[i].txt;
			document.getElementById(i).style.resize='none';
			document.getElementById(i).disabled = 'true';
		}
	}		
}


//Performs search in 5-second intervals
setInterval(function() {
	var bod = document.getElementsByClassName('texts');
	console.log(bod.length);
	
	//Using ajax for connections
	$.ajax({
		  url: "/gerar/"+bod.length,
		  type: "GET",		  
		  success: function(response,status) {
			  console.log(response);
			  for(var i=0; i<bod.length; i++){
				  bod[i].value = response[i].texto;	
				  bod[i].style.backgroundColor=response[i].corCx;
				  bod[i].style.color=response[i].corTxt;
			  }
		  }		 
	});
	
}, 5000);
