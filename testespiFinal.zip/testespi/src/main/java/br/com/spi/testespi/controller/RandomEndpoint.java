package br.com.spi.testespi.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.spi.testespi.model.CxText;
import ch.qos.logback.core.net.SyslogOutputStream;

@Controller
@RestController
public class RandomEndpoint {
	
	//Random value generator for the textareas
	//Returns list of values for textareas
	//Example : for two existing textareas  -> return two list items for front
	
	@GetMapping("/gerar/{qtd}")
	public ResponseEntity<?> gerar(@PathVariable Integer qtd){
		System.out.println("Ola mundo");
		System.out.println(qtd);
		List<CxText> lista = new ArrayList<>();
		for(int i=0; i<qtd; i++)
			lista.add(gerarCx());
		return ResponseEntity.ok(lista);
	}
	
	private CxText gerarCx(){
		StringBuilder texto = new StringBuilder("");
		StringBuilder corCx = new StringBuilder("");
		StringBuilder corText = new StringBuilder("");
 		int size = (int) (Math.random()*101);
		size+=2;
		int letra;		
		for(int i=0; i<size; i++){
			letra = (int) (Math.random()*(126-33));
			letra+=33;
			texto.append((char)(letra));			
		}
		for(int j = 0; j<3; j++){	
			letra = (int) (Math.random()*256);
			corCx.append(letra+",");
			letra = (int) (Math.random()*256);
			corText.append(letra+",");
		}
		corCx.deleteCharAt(corCx.length()-1);
		corCx = new StringBuilder("rgb("+corCx+")");
		corText = new StringBuilder("rgb("+corText+")");
		return new CxText(texto,corText,corCx);
	}
}
