package br.com.spi.testespi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


//Start for RESTapi 

@SpringBootApplication
public class TestespiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestespiApplication.class, args);
	}
}
