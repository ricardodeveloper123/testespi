package br.com.spi.testespi.model;

public class CxText {
	private StringBuilder texto;
	private StringBuilder corTxt;
	private StringBuilder corCx;
	
	
	public CxText(StringBuilder texto, StringBuilder corTxt, StringBuilder corCx) {
		super();
		this.texto = texto;
		this.corTxt = corTxt;
		this.corCx = corCx;
	}
	public StringBuilder getTexto() {
		return texto;
	}
	public void setTexto(StringBuilder texto) {
		this.texto = texto;
	}
	public StringBuilder getCorTxt() {
		return corTxt;
	}
	public void setCorTxt(StringBuilder corTxt) {
		this.corTxt = corTxt;
	}
	public StringBuilder getCorCx() {
		return corCx;
	}
	public void setCorCx(StringBuilder corCx) {
		this.corCx = corCx;
	}
	
	
}
