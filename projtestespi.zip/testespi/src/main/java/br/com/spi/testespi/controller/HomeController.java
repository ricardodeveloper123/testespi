package br.com.spi.testespi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/aleatorio")
	public String aleatorio(){
		return "aleatorio";
	}
	@RequestMapping("/exibir")
	public String exibir(){
		return "exibir";
	}
	@RequestMapping("/index")
	public String index(){
		return "index";
	}
}
